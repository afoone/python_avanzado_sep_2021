# operaciones geométricas

def hipotenusa(cateto_a: float, cateto_b: float) -> float:
    return pow(pow(cateto_a, 2) + pow(cateto_b, 2), 0.5)

